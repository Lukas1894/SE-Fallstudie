/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Kevin
 */
@Entity
@Table(name = "anbieter")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Anbieter.findAll", query = "SELECT a FROM Anbieter a")
    , @NamedQuery(name = "Anbieter.findById", query = "SELECT a FROM Anbieter a WHERE a.id = :id")
    , @NamedQuery(name = "Anbieter.findByAnbieter", query = "SELECT a FROM Anbieter a WHERE a.anbieter = :anbieter")
    , @NamedQuery(name = "Anbieter.findByIntExt", query = "SELECT a FROM Anbieter a WHERE a.intExt = :intExt")
    , @NamedQuery(name = "Anbieter.findByBankkonto", query = "SELECT a FROM Anbieter a WHERE a.bankkonto = :bankkonto")
    , @NamedQuery(name = "Anbieter.findByTelefonnummer", query = "SELECT a FROM Anbieter a WHERE a.telefonnummer = :telefonnummer")
    , @NamedQuery(name = "Anbieter.findByPlz", query = "SELECT a FROM Anbieter a WHERE a.plz = :plz")
    , @NamedQuery(name = "Anbieter.findByOrt", query = "SELECT a FROM Anbieter a WHERE a.ort = :ort")
    , @NamedQuery(name = "Anbieter.findByStrasse", query = "SELECT a FROM Anbieter a WHERE a.strasse = :strasse")
    , @NamedQuery(name = "Anbieter.findByEMail", query = "SELECT a FROM Anbieter a WHERE a.eMail = :eMail")})
public class Anbieter implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Short id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "Anbieter")
    private String anbieter;
    @Size(max = 10)
    @Column(name = "int_ext")
    private String intExt;
    @Size(max = 50)
    @Column(name = "Bankkonto")
    private String bankkonto;
    @Size(max = 20)
    @Column(name = "Telefonnummer")
    private String telefonnummer;
    @Column(name = "PLZ")
    private Integer plz;
    @Size(max = 50)
    @Column(name = "Ort")
    private String ort;
    @Size(max = 50)
    @Column(name = "Strasse")
    private String strasse;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 50)
    @Column(name = "E_Mail")
    private String eMail;

    public Anbieter() {
    }

    public Anbieter(Short id) {
        this.id = id;
    }

    public Anbieter(Short id, String anbieter) {
        this.id = id;
        this.anbieter = anbieter;
    }

    public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public String getAnbieter() {
        return anbieter;
    }

    public void setAnbieter(String anbieter) {
        this.anbieter = anbieter;
    }

    public String getIntExt() {
        return intExt;
    }

    public void setIntExt(String intExt) {
        this.intExt = intExt;
    }

    public String getBankkonto() {
        return bankkonto;
    }

    public void setBankkonto(String bankkonto) {
        this.bankkonto = bankkonto;
    }

    public String getTelefonnummer() {
        return telefonnummer;
    }

    public void setTelefonnummer(String telefonnummer) {
        this.telefonnummer = telefonnummer;
    }

    public Integer getPlz() {
        return plz;
    }

    public void setPlz(Integer plz) {
        this.plz = plz;
    }

    public String getOrt() {
        return ort;
    }

    public void setOrt(String ort) {
        this.ort = ort;
    }

    public String getStrasse() {
        return strasse;
    }

    public void setStrasse(String strasse) {
        this.strasse = strasse;
    }

    public String getEMail() {
        return eMail;
    }

    public void setEMail(String eMail) {
        this.eMail = eMail;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Anbieter)) {
            return false;
        }
        Anbieter other = (Anbieter) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Anbieter[ id=" + id + " ]";
    }
    
}
