/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Kevin
 */
@Entity
@Table(name = "seminare")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Seminare.findAll", query = "SELECT s FROM Seminare s")
    , @NamedQuery(name = "Seminare.findBySeminarnummer", query = "SELECT s FROM Seminare s WHERE s.seminarnummer = :seminarnummer")
    , @NamedQuery(name = "Seminare.findByAnbieter", query = "SELECT s FROM Seminare s WHERE s.anbieter = :anbieter")
    , @NamedQuery(name = "Seminare.findByBankkonto", query = "SELECT s FROM Seminare s WHERE s.bankkonto = :bankkonto")
    , @NamedQuery(name = "Seminare.findByPlz", query = "SELECT s FROM Seminare s WHERE s.plz = :plz")
    , @NamedQuery(name = "Seminare.findByOrt", query = "SELECT s FROM Seminare s WHERE s.ort = :ort")
    , @NamedQuery(name = "Seminare.findByStrasse", query = "SELECT s FROM Seminare s WHERE s.strasse = :strasse")
    , @NamedQuery(name = "Seminare.findByEMail", query = "SELECT s FROM Seminare s WHERE s.eMail = :eMail")})
public class Seminare implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "Seminarnummer")
    private String seminarnummer;
    @Size(max = 50)
    @Column(name = "Anbieter")
    private String anbieter;
    @Size(max = 50)
    @Column(name = "Bankkonto")
    private String bankkonto;
    @Size(max = 20)
    @Column(name = "PLZ")
    private String plz;
    @Size(max = 50)
    @Column(name = "Ort")
    private String ort;
    @Size(max = 50)
    @Column(name = "Strasse")
    private String strasse;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 80)
    @Column(name = "EMail")
    private String eMail;
    
    @Size(max = 80)
    @Column (name = "Bezeichnung")
    private String bezeichnung;

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public void setBezeichnung(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    public Seminare() {
    }

    public Seminare(String seminarnummer) {
        this.seminarnummer = seminarnummer;
    }

    public String getSeminarnummer() {
        return seminarnummer;
    }

    public void setSeminarnummer(String seminarnummer) {
        this.seminarnummer = seminarnummer;
    }

    public String getAnbieter() {
        return anbieter;
    }

    public void setAnbieter(String anbieter) {
        this.anbieter = anbieter;
    }

    public String getBankkonto() {
        return bankkonto;
    }

    public void setBankkonto(String bankkonto) {
        this.bankkonto = bankkonto;
    }

    public String getPlz() {
        return plz;
    }

    public void setPlz(String plz) {
        this.plz = plz;
    }

    public String getOrt() {
        return ort;
    }

    public void setOrt(String ort) {
        this.ort = ort;
    }

    public String getStrasse() {
        return strasse;
    }

    public void setStrasse(String strasse) {
        this.strasse = strasse;
    }

    public String getEMail() {
        return eMail;
    }

    public void setEMail(String eMail) {
        this.eMail = eMail;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (seminarnummer != null ? seminarnummer.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Seminare)) {
            return false;
        }
        Seminare other = (Seminare) object;
        if ((this.seminarnummer == null && other.seminarnummer != null) || (this.seminarnummer != null && !this.seminarnummer.equals(other.seminarnummer))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Seminare[ seminarnummer=" + seminarnummer + " ]";
    }
    
}
