/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Kevin
 */
@Entity
@Table(name = "mitarbeiter")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mitarbeiter.findAll", query = "SELECT m FROM Mitarbeiter m")
    , @NamedQuery(name = "Mitarbeiter.findByVorName", query = "SELECT m FROM Mitarbeiter m WHERE m.vorName = :vorName")
    , @NamedQuery(name = "Mitarbeiter.findByNachName", query = "SELECT m FROM Mitarbeiter m WHERE m.nachName = :nachName")
    , @NamedQuery(name = "Mitarbeiter.findByPNummer", query = "SELECT m FROM Mitarbeiter m WHERE m.pNummer = :pNummer")
    , @NamedQuery(name = "Mitarbeiter.findByOrganisationseinheit", query = "SELECT m FROM Mitarbeiter m WHERE m.organisationseinheit = :organisationseinheit")
    , @NamedQuery(name = "Mitarbeiter.findByStelle", query = "SELECT m FROM Mitarbeiter m WHERE m.stelle = :stelle")
    , @NamedQuery(name = "Mitarbeiter.findByTelefon", query = "SELECT m FROM Mitarbeiter m WHERE m.telefon = :telefon")
    , @NamedQuery(name = "Mitarbeiter.findByEmail", query = "SELECT m FROM Mitarbeiter m WHERE m.email = :email")})
public class Mitarbeiter implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 50)
    @Column(name = "vorName")
    private String vorName;
    @Size(max = 50)
    @Column(name = "nachName")
    private String nachName;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "p_nummer")
    private String pNummer;
    @Size(max = 25)
    @Column(name = "organisationseinheit")
    private String organisationseinheit;
    @Size(max = 10)
    @Column(name = "stelle")
    private String stelle;
    @Column(name = "telefon")
    private Integer telefon;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 50)
    @Column(name = "email")
    private String email;

    public Mitarbeiter() {
    }

    public Mitarbeiter(String pNummer) {
        this.pNummer = pNummer;
    }

    public String getVorName() {
        return vorName;
    }

    public void setVorName(String vorName) {
        this.vorName = vorName;
    }

    public String getNachName() {
        return nachName;
    }

    public void setNachName(String nachName) {
        this.nachName = nachName;
    }

    public String getPNummer() {
        return pNummer;
    }

    public void setPNummer(String pNummer) {
        this.pNummer = pNummer;
    }

    public String getOrganisationseinheit() {
        return organisationseinheit;
    }

    public void setOrganisationseinheit(String organisationseinheit) {
        this.organisationseinheit = organisationseinheit;
    }

    public String getStelle() {
        return stelle;
    }

    public void setStelle(String stelle) {
        this.stelle = stelle;
    }

    public Integer getTelefon() {
        return telefon;
    }

    public void setTelefon(Integer telefon) {
        this.telefon = telefon;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pNummer != null ? pNummer.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mitarbeiter)) {
            return false;
        }
        Mitarbeiter other = (Mitarbeiter) object;
        if ((this.pNummer == null && other.pNummer != null) || (this.pNummer != null && !this.pNummer.equals(other.pNummer))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Mitarbeiter[ pNummer=" + pNummer + " ]";
    }
    
}
