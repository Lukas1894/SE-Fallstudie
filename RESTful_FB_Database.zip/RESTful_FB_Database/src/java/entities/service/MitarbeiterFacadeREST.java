/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities.service;

import entities.Mitarbeiter;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import static entities.Mitarbeiter_.pNummer;

/**
 *
 * @author Kevin
 */
@Stateless
@Path("entities.mitarbeiter")
public class MitarbeiterFacadeREST {

    @PersistenceContext(unitName = "RESTful_FB_DatabasePU")
    private EntityManager em;

    public MitarbeiterFacadeREST() {
        
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String create(String json) {
        Gson gson = new GsonBuilder().create();
        Mitarbeiter mitarbeiter = gson.fromJson(json, Mitarbeiter.class);
        mitarbeiter = em.merge(mitarbeiter);
        
        return gson.toJson(mitarbeiter);
        
    }


    @DELETE
    @Path("{pNummer}")
    @Produces({MediaType.APPLICATION_JSON})
     public String removeMitarbeiter(String json){ 
        Mitarbeiter mitarbeiter = em.find(Mitarbeiter.class , pNummer);
        em.remove(mitarbeiter);
        Gson gson = new GsonBuilder().create();
       
        return gson.toJson(mitarbeiter);
     }
        
    

    @GET
    @Path("{p_nummer}")
    @Produces({MediaType.APPLICATION_JSON})
    public String getListJson(){
        return null;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {
        List<Mitarbeiter> mitarbeiter = em.createQuery("SELECT m FROM Mitarbeiter m").getResultList();
        Gson gson = new GsonBuilder().create();
        return gson.toJson(mitarbeiter);
        
    }
    
}
