/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import entities.Mitarbeiter;
import entities.Seminare;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Kevin
 */
@Stateless
@Path("entities.seminare")
public class SeminareFacadeREST {

    @PersistenceContext(unitName = "RESTful_FB_DatabasePU")
    private EntityManager em;

    public SeminareFacadeREST() {
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String create(String json) {
        Gson gson = new GsonBuilder().create();
        Seminare seminare = gson.fromJson(json, Seminare.class);
        seminare = em.merge(seminare);
        
        return gson.toJson(seminare);
        
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {
        List<Seminare> seminare = em.createQuery("SELECT s FROM Seminare s").getResultList();
        Gson gson = new GsonBuilder().create();
        return gson.toJson(seminare);
        
    }

  

   

    

    
    
}
