/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import entities.Anbieter;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Kevin
 */
@Stateless
@Path("entities.anbieter")
public class AnbieterFacadeREST{

    @PersistenceContext(unitName = "RESTful_FB_DatabasePU")
    private EntityManager em;

    public AnbieterFacadeREST(){   
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String create(String json) {
    Gson gson = new GsonBuilder().create();
    Anbieter anbieter = gson.fromJson(json, Anbieter.class);
    anbieter = em.merge(anbieter);
        
    return gson.toJson(anbieter);
        
    }
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String findAll() {
        List<Anbieter> anbieter = em.createQuery("SELECT a FROM Anbieter a").getResultList();
        Gson gson = new GsonBuilder().create();
        return gson.toJson(anbieter);
        
    }
}
