/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
  function mitarbeiter_anlegen(){
            var p_nummer = document.getElementById("p_nummer").value;
            var vorname = document.getElementById("vorname").value;
            var nachname = document.getElementById("nachname").value;
            var organisationseinheit = document.getElementById("organisationseinheit").value;
            var stelle = document.getElementById("stelle").value;
            var e_mail = document.getElementById("e_mail").value;
            var telefon= document.getElementById("telefonnummer").value;
            
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "webresources/entities.mitarbeiter",true);
            ajax.responseType = "json";
            ajax.setRequestHeader("Content-Type", "application/json");
            
            ajax.addEventListener("load", function() {
                window.alert("Datensatz erfolgreich angelegt!");
            });
            ajax.addEventListener("error", function() {
                window.alert("Datensatz konnte nicht angelegt werden");
            });
            
            ajax.send(JSON.stringify({
            vorName: vorname,
            nachName: nachname,
            pNummer: p_nummer,
            organisationseinheit: organisationseinheit,
            stelle: stelle,
            telefon: telefon,
            email:e_mail
            }));
            
            document.getElementById("p_nummer").value="";
            document.getElementById("vorname").value="";
            document.getElementById("nachname").value="";
            document.getElementById("organisationseinheit").value="";
            document.getElementById("stelle").value="";
            document.getElementById("e_mail").value="";
            document.getElementById("telefonnummer").value="";
            }
            function anzeigenMitarbeiter(){
            var mitarbeiterListe = document.getElementById("tabelle");
            mitarbeiterListe.innerHTML="";
            var tabellenkopf = document.getElementById("tabellenkopf");
            tabellenkopf.innerHTML="";
            
            var ajax = new XMLHttpRequest();
            ajax.open ("GET","webresources/entities.mitarbeiter",true);
            ajax.responseType = "json";
            
            ajax.addEventListener("load", function(){
               ajax.response.forEach(function (mitarbeiter){
               
                var html =
                
                "<table><tr><td>"+mitarbeiter.pNummer+"</td><td>"+mitarbeiter.vorName+"</td><td>"+mitarbeiter.nachName+"</td><td>" +mitarbeiter.organisationseinheit+"</td><td>"+mitarbeiter.stelle+"</td><td>"+ mitarbeiter.telefon+"</td><td>"+mitarbeiter.email+"</td></tr></table>";    
                mitarbeiterListe.innerHTML += html;
               });
               var html_2 = "<table><tr><th>P-Nummer</th><th>Vorname</th><th>Nachname</th><th>Organisationseinheit</th><th>Stelle</th><th>Telefonnummer</th><th>E-Mail</th></tr></table>";
               tabellenkopf.innerHTML += html_2;
            });
            ajax.send();
            }
           function anlegenSeminar(){
               var semnr = document.getElementById("Seminarnummer").value;
               var bez = document.getElementById("Seminarbezeichnung").value;
               var anb = document.getElementById("Anbieter").value;
               var bnkkonto = document.getElementById("Bankkonto").value;
               var plz = document.getElementById("PLZ").value;
               var ort = document.getElementById("Ort").value;
               var strasse = document.getElementById("Strasse").value;
               var email = document.getElementById("EMail").value;
               
               var ajax = new XMLHttpRequest();
               ajax.open("POST","webresources/entities.seminare",true);
               ajax.responseType = "json";
               ajax.setRequestHeader("Content-Type", "application/json");
               
               ajax.send(JSON.stringify({
               seminarnummer : semnr,
               bezeichnung : bez,
               anbieter : anb,
               bankkonto : bnkkonto,
               plz : plz,
               ort : ort,
               strasse : strasse,
               eMail : email
               }));
           }
           function seminareAnzeigen(){
            var seminarListe = document.getElementById("seminarliste");
            seminarListe.innerHTML="";
            var tabellenkopf_2 = document.getElementById("tabellenkopf2");
            tabellenkopf_2.innerHTML="";
            
            var ajax = new XMLHttpRequest();
            ajax.open ("GET","webresources/entities.seminare",true);
            ajax.responseType = "json";
            
            ajax.addEventListener("load", function(){
               ajax.response.forEach(function (seminare){
               
                var html = "<table><tr><td>"+seminare.seminarnummer+"</td><td>"+seminare.bezeichnung+"</td><td>"+seminare.anbieter+"</td><td>"+seminare.bankkonto+"</td><td>"+seminare.plz+"</td><td>"+seminare.ort+"</td><td>"+seminare.strasse+"</td><td>"+seminare.eMail+"</td></tr></table><button id='seminar_löschen' type='submit'>Seminar löschen</button>";
                    seminarListe.innerHTML += html;
               });
                var html_2 = "<table><tr><th>Seminarnummer</th><th>Seminarbezeichnung</th><th>Anbieter</th><th>Bankkonto</th><th>PLZ</th><th>Ort</th><th>Strasse</th><th>E-Mail</th></tr></table>";
               tabellenkopf_2.innerHTML += html_2;
            });
            ajax.send();
            }

