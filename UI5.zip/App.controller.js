sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.ui.demo.wt.App", {

		onShowHello : function () {
			// show a native JavaScript alert
			alert("View und Controller sind beide außerhalb der HTML-Datei.");
		}
	});

});