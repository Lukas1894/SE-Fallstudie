sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("sap.ui.demo.wt.Step_4_App", {

		onShowHello : function () {
			alert("View und Controller sind beide außerhalb der HTML-Datei.");
		}
	});

});